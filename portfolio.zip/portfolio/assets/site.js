(function () {
  'use strict';

  /* Базове посилання на репозиторій. Після створення репозиторію замініть на
     https://github.com/<користувач>/<репозиторій> — усі кнопки «Код на GitHub»
     оновляться автоматично та вестимуть у потрібну папку проєкту. */
  var REPO_URL = '';
  var BRANCH = 'main';

  if (REPO_URL) {
    document.querySelectorAll('[data-code]').forEach(function (a) {
      a.href = REPO_URL.replace(/\/$/, '') + '/tree/' + BRANCH + '/' + a.dataset.code;
    });
  }

  /* Мобільне меню */
  var burger = document.querySelector('.burger');
  var links = document.getElementById('nav-links');
  burger.addEventListener('click', function () {
    var open = burger.getAttribute('aria-expanded') !== 'true';
    burger.setAttribute('aria-expanded', String(open));
    burger.setAttribute('aria-label', open ? 'Закрити меню' : 'Відкрити меню');
    links.classList.toggle('open', open);
  });
  links.addEventListener('click', function (e) {
    if (e.target.closest('a')) {
      burger.setAttribute('aria-expanded', 'false');
      links.classList.remove('open');
    }
  });

  /* М'яка поява блоків при прокрутці */
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
      });
    }, { threshold: 0.12 });
    document.querySelectorAll('.project, .services li, .steps li').forEach(function (el) {
      el.classList.add('reveal'); io.observe(el);
    });
  }
})();
