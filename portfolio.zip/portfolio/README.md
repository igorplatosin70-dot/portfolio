# Портфоліо — Платошин Марина

Статичний сайт без збірки: HTML + CSS + JavaScript. 5 робочих демо-проєктів у `projects/`.

## Запуск
Відкрийте `index.html` у браузері (або `npx serve .` / `python3 -m http.server`).

## Публікація на Netlify
Перетягніть цю папку на https://app.netlify.com/drop (або у Deploys існуючого сайту). Збірка не потрібна.

## GitHub-посилання
У `assets/site.js` задайте `REPO_URL = 'https://github.com/<користувач>/<репозиторій>'` — усі кнопки «Код на GitHub» поведуть у папки проєктів.

## Проєкти
| Папка | Що це |
|---|---|
| projects/cafe | Бізнес-сайт: меню, статус відкрито/зачинено, форма бронювання |
| projects/store | Магазин: пошук, фільтри, кошик, промокод DEMO10 |
| projects/dashboard | Кабінет: вхід demo@portfolio.dev / demo1234, таблиця, графік, CSV |
| projects/tasks | Менеджер завдань: CRUD, фільтри, undo, localStorage |
| projects/weather | Погода на REST API Open-Meteo |
